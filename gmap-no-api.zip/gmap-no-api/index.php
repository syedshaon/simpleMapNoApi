<?php
/*
 * Plugin Name: Simple Map No Api
 * Plugin URI: https://github.com/syedshaon/simpleMapNoApi
 * Description: Simple Google map that is 100% responsive and doesn't require google map api.
 * Version: 1.0
 * Author: Syed Mashiur Rahman
 * Author URI: http://mashimakes.website/
 * Text Domain: simple-map-no-api
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * License:           GPL v3 or later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.en.html
 */

if( !function_exists( 'add_action' ) ){
	die( "Hi there! I'm just a plugin, not much I can do when called directly." );
}


// Support shortcode in widgets

add_filter('widget_text', 'do_shortcode');


function mapOption()
{
    add_menu_page('Simple Map No Api', 'Map Options', 'administrator', 'mapOption', 'adjustments', 'dashicons-location-alt', 99);

};

add_action('admin_menu', 'mapOption');

function theme_settings()
{
    register_setting('gmap_setting', 'gmap_latitude');
    register_setting('gmap_setting', 'gmap_longitude');
    register_setting('gmap_setting', 'gmap_width');
    register_setting('gmap_setting', 'gmap_height');
    register_setting('gmap_setting', 'gmap_title');
}

add_action('init', 'theme_settings');






function adjustments()
{
    ?>

<div class="wrap">
    <h1>Google Map Adjustments</h1>
    <form action="options.php" method="post">
        <?php
        settings_fields('gmap_setting');
        do_settings_sections('gmap_setting') ?>
      
        <table class="form-table">
            <tr valing="top">
                <th scope="row">Latitude : </th>
                <td>
                    <input placeholder="Location's latitude here like: 40.6773988" class="regular-text"  type="text" name="gmap_latitude"
                        value="<?php echo esc_attr(get_option('gmap_latitude')); ?>">
                </td>
            </tr>
            <tr valing="top">
                <th scope="row">Longitude : </th>
                <td>
                    <input placeholder="Location's longitude here like: -85.6134087" class="regular-text" type="text" name="gmap_longitude"
                        value="<?php echo esc_attr(get_option('gmap_longitude')); ?>">
                </td>
            </tr>

            <tr valing="top">
                <th scope="row">Width : </th>
                <td>
                    <input placeholder="Desired width of your map, default 100%" class="regular-text"  type="text" name="gmap_width"
                        value="<?php echo esc_attr(get_option('gmap_width')); ?>">
                        <span>Optional</span>
                </td>
            </tr>
            <tr valing="top">
                <th scope="row">Height : </th>
                <td>
                    <input placeholder="Desired width of your map, default 400px" class="regular-text"  type="text" name="gmap_height"
                        value="<?php echo esc_attr(get_option('gmap_height')); ?>"> <span>Optional</span>
                </td>
            </tr>


            <tr valing="top">
                <th scope="row">Location Title : </th>
                <td>
                    <input placeholder="Desired Title of your map." class="regular-text" type="text" name="gmap_title"
                        value="<?php echo esc_attr(get_option('gmap_title')); ?>">
                        <span>Optional</span>
                </td>
            </tr>


        </table>
        <?php submit_button(); ?>
    </form>
    
    <br>
    <h2>Instructions:</h2>
    <p>After putting required information in the above form put the shortcode <span style="color:red; font-weight:bold;">[simpleMapNoApi]</span>  in pages where you want the map to show up. Done!</p>
    <p>For Video Instruction please visit this <a href="https://youtu.be/bQwq5WKh0y0">Youtube link</a></p>
    <p>Or, visit this  <a href="https://github.com/syedshaon/simpleMapNoApi"> github page</a> for detailed instruction.</p>
    

</div>




<?php };


?>


<?php 


function createSimpleMap(){

    if(get_option('gmap_latitude')){
       
         $latitude =get_option('gmap_latitude');
    }else{
        $latitude = 35.136650;
    }

    if(get_option('gmap_longitude')){
       
         $longitude =get_option('gmap_longitude');
    }else{
        $longitude = -117.944734;
    }

    
    if(get_option('gmap_height')){
       
         $getHeight =(int) filter_var(get_option('gmap_height'), FILTER_SANITIZE_NUMBER_INT);
         $height = $getHeight."px";
    }else{
        $height = "400px";
    }

    if(get_option('gmap_width')){       
         $width = get_option('gmap_width');
    }else{
        $width = "100%";
    }
    ob_start();?>
   

    <div id="simpleMap" style="overflow:hidden; width:<?php echo $width; ?>; margin:0 auto; position: relative;">
        <div class="fluid-width-video-wrapper" style="padding-top:<?php echo $height; ?> !important;">
            <iframe 
                src="https://maps.google.com/maps?q=<?php echo $latitude; ?>,<?php echo $longitude; ?>&hl=en;z=14&amp;output=embed"
                width="100%"
                frameborder="0"
                style="height:<?php echo $height; ?>; width:100%;  padding:0 !important;"
                allowfullscreen=""
                >
            </iframe> 
        
        </div>
        <?php if(get_option('gmap_title')){ ?>
        
        <div class="simpleMap-info" 
            style="position: absolute;
                    top: 11px;
                    left: 11px;
                    z-index: 333;                
                    text-align:left;
                    background-color: #fff;
                    padding: 5px 0 0 5px;
                    width:225px;
                    ">
            <span style="color: red; font-size:1.8rem; font-weight: bold; text-shadow: 2px 5px 10px rgba(0,0,0,0.65);">
            <?php echo get_option('gmap_title'); ?>
            </span> 
        </div>  

        <?php } ?> 

             
    </div>
				

    <?php $content = ob_get_clean();
    return $content;

}

add_shortcode('simpleMapNoApi', 'createSimpleMap');

